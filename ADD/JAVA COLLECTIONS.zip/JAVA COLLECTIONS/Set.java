import java.util.*;
public class Set {
    public static void main(String[]args) {
       
        Set t=new Set();
        t.add(20);
        System.out.println(t);
    }
}
    
    

