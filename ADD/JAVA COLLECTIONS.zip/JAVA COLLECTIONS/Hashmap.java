import java.util.*;
public class Hashmap {
    public  static void main(String[]args)
    {
HashMap hm=new HashMap<>();
hm.put(1, 200);
hm.put(2, 300);
System.out.println(hm);
hm.get(2);
hm.remove(2);
System.out.println(hm);


    }
}
