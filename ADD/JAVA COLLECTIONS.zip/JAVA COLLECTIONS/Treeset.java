import java.util.*;
public class Treeset {
   public static void main(String[]args) 
   {
       TreeSet ts=new TreeSet<>();
       ts.add(10);
ts.add(20);
System.out.println(ts);

   }
}
