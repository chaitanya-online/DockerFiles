import java.util.*;
public class Hashset {
    public static void main(String[]args)
    {
        HashSet hs=new HashSet<>();
        hs.add(10);
        hs.add(20);
        System.out.println(hs);
    }
}
