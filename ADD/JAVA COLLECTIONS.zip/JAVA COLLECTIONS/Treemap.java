import java.util.*;
public class Treemap {
   public static void main(String[]args) 
   {
       TreeMap tm=new TreeMap<>();
       tm.put(10, 100);
       tm.put(20, 200);
       tm.get(20);
   }
}
